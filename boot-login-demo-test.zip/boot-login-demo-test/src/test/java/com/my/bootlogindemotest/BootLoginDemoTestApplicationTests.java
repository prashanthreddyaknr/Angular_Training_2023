package com.my.bootlogindemotest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootLoginDemoTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
