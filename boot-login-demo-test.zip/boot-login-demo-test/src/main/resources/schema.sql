create table app_users(
id number(5),
user_name varchar2(100),
password varchar2(100)
);