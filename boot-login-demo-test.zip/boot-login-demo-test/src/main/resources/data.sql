insert into app_users (id, user_name, password) values (1, 'Sravan', 'Sravan@123');
insert into app_users (id, user_name, password) values (2, 'Jhon', 'Jhon@123');
insert into app_users (id, user_name, password) values (3, 'Joe', 'Joe@123');
insert into app_users (id, user_name, password) values (4, 'Hogan', 'Hogan@123');
insert into app_users (id, user_name, password) values (5, 'Will', 'Will@123');