package com.my.bootlogindemotest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootLoginDemoTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootLoginDemoTestApplication.class, args);
	}

}
