package com.my.bootlogindemotest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	public Boolean authenticate(User user) {
		List<User> users = userRepository.findAll();
        System.out.println("#################### usrers : "+users);
		Optional<User> userOptional = users.stream().filter(usr -> usr.getUserName().equals(user.getUserName()) && usr.getPassword().equals(user.getPassword())).findAny();
		return userOptional.isPresent()? (userOptional.get().getUserName().equals(user.getUserName()) && userOptional.get().getPassword().equals(user.getPassword())) : false;
	}

}
